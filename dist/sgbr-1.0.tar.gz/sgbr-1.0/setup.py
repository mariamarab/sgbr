from distutils.core import setup

setup(name='sgbr',
      version='1.0',
      py_modules=['sgbr'],
      )
